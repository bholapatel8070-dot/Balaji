/* =============================================
   SHRI BALAJI RESORT — script.js
   All interactive features & animations
   ============================================= */

'use strict';

/* ==============================
   1. PRELOADER
   ============================== */
window.addEventListener('load', () => {
  setTimeout(() => {
    const preloader = document.getElementById('preloader');
    if (preloader) {
      preloader.classList.add('hidden');
      // Remove from DOM after transition
      preloader.addEventListener('transitionend', () => preloader.remove());
    }
    // Init AOS after preloader
    AOS.init({
      duration: 700,
      once: true,
      offset: 60,
      easing: 'ease-out-cubic'
    });
    // Start particles
    initParticles();
  }, 2000);
});

/* ==============================
   2. NAVBAR — STICKY + HAMBURGER
   ============================== */
const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('nav-links');

// Sticky scroll
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// Hamburger toggle
hamburger.addEventListener('click', () => {
  navLinks.classList.toggle('active');
  // Animate hamburger lines
  const spans = hamburger.querySelectorAll('span');
  if (navLinks.classList.contains('active')) {
    spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
    spans[1].style.opacity = '0';
    spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
  } else {
    spans[0].style.transform = '';
    spans[1].style.opacity = '';
    spans[2].style.transform = '';
  }
});

// Close menu on link click
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('active');
    hamburger.querySelectorAll('span').forEach(s => {
      s.style.transform = '';
      s.style.opacity = '';
    });
  });
});

// Active nav link on scroll
const sections = document.querySelectorAll('section[id]');
window.addEventListener('scroll', () => {
  const scrollPos = window.scrollY + 100;
  sections.forEach(sec => {
    if (scrollPos >= sec.offsetTop && scrollPos < sec.offsetTop + sec.offsetHeight) {
      document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
      const active = document.querySelector(`.nav-link[href="#${sec.id}"]`);
      if (active) active.classList.add('active');
    }
  });
});

/* ==============================
   3. BACK TO TOP BUTTON
   ============================== */
const backToTop = document.getElementById('back-to-top');
window.addEventListener('scroll', () => {
  if (window.scrollY > 400) {
    backToTop.classList.add('visible');
  } else {
    backToTop.classList.remove('visible');
  }
});
backToTop.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ==============================
   4. DARK MODE TOGGLE
   ============================== */
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const body = document.body;

// Check saved preference
if (localStorage.getItem('theme') === 'dark') {
  body.classList.remove('light-mode');
  themeIcon.className = 'fa-solid fa-sun';
} else {
  body.classList.add('light-mode');
  themeIcon.className = 'fa-solid fa-moon';
}

themeToggle.addEventListener('click', () => {
  body.classList.toggle('light-mode');
  if (body.classList.contains('light-mode')) {
    themeIcon.className = 'fa-solid fa-moon';
    localStorage.setItem('theme', 'light');
  } else {
    themeIcon.className = 'fa-solid fa-sun';
    localStorage.setItem('theme', 'dark');
  }
});

/* ==============================
   5. FLOATING PARTICLES CANVAS
   ============================== */
function initParticles() {
  const canvas = document.getElementById('particles-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let particles = [];
  let W, H;

  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // Create particles
  function createParticle() {
    return {
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 2 + 0.5,
      dx: (Math.random() - 0.5) * 0.4,
      dy: -Math.random() * 0.6 - 0.2,
      opacity: Math.random() * 0.5 + 0.1,
      pulse: Math.random() * Math.PI * 2
    };
  }

  for (let i = 0; i < 80; i++) particles.push(createParticle());

  function drawParticles() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach((p, i) => {
      p.pulse += 0.02;
      const alpha = p.opacity * (0.7 + 0.3 * Math.sin(p.pulse));
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(201, 168, 76, ${alpha})`;
      ctx.shadowColor = 'rgba(201, 168, 76, 0.6)';
      ctx.shadowBlur = 6;
      ctx.fill();

      p.x += p.dx;
      p.y += p.dy;

      // Reset particle when off screen
      if (p.y < -10 || p.x < -10 || p.x > W + 10) {
        particles[i] = createParticle();
        particles[i].y = H + 10; // start from bottom
      }
    });
    requestAnimationFrame(drawParticles);
  }
  drawParticles();
}

/* ==============================
   6. GALLERY LIGHTBOX
   ============================== */
const galleryImages = [
  'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1200&q=90',
  'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200&q=90',
  'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?w=1200&q=90',
  'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=1200&q=90',
  'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1200&q=90',
  'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&q=90'
];

let currentLightboxIndex = 0;

function openLightbox(index) {
  currentLightboxIndex = index;
  const lightbox = document.getElementById('lightbox');
  const img = document.getElementById('lightbox-img');
  img.src = galleryImages[index];
  lightbox.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  document.getElementById('lightbox').classList.remove('active');
  document.body.style.overflow = '';
}

function changeLightbox(dir) {
  currentLightboxIndex = (currentLightboxIndex + dir + galleryImages.length) % galleryImages.length;
  document.getElementById('lightbox-img').src = galleryImages[currentLightboxIndex];
}

// Close on background click
document.getElementById('lightbox').addEventListener('click', function(e) {
  if (e.target === this) closeLightbox();
});

// Keyboard navigation
document.addEventListener('keydown', e => {
  const lb = document.getElementById('lightbox');
  if (!lb.classList.contains('active')) return;
  if (e.key === 'Escape') closeLightbox();
  if (e.key === 'ArrowLeft') changeLightbox(-1);
  if (e.key === 'ArrowRight') changeLightbox(1);
});

/* ==============================
   7. TESTIMONIAL SLIDER
   ============================== */
const track = document.getElementById('testimonial-track');
const dotsContainer = document.getElementById('slider-dots');

let currentSlide = 0;
let autoSlideInterval;
const totalSlides = track ? track.children.length : 0;

// Build dots
if (dotsContainer && totalSlides > 0) {
  for (let i = 0; i < totalSlides; i++) {
    const dot = document.createElement('div');
    dot.className = `dot${i === 0 ? ' active' : ''}`;
    dot.addEventListener('click', () => goToSlide(i));
    dotsContainer.appendChild(dot);
  }
}

function goToSlide(index) {
  currentSlide = index;
  track.scrollTo({ left: index * track.offsetWidth, behavior: 'smooth' });
  document.querySelectorAll('.dot').forEach((d, i) => {
    d.classList.toggle('active', i === index);
  });
}

function moveSlider(dir) {
  const next = (currentSlide + dir + totalSlides) % totalSlides;
  goToSlide(next);
  resetAutoSlide();
}

function resetAutoSlide() {
  clearInterval(autoSlideInterval);
  autoSlideInterval = setInterval(() => moveSlider(1), 5000);
}

// Auto-slide
autoSlideInterval = setInterval(() => moveSlider(1), 5000);

// Pause on hover
if (track) {
  track.addEventListener('mouseenter', () => clearInterval(autoSlideInterval));
  track.addEventListener('mouseleave', resetAutoSlide);

  // Touch swipe support
  let touchStartX = 0;
  track.addEventListener('touchstart', e => { touchStartX = e.changedTouches[0].clientX; }, { passive: true });
  track.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) moveSlider(diff > 0 ? 1 : -1);
  });
}

/* ==============================
   8. CONTACT FORM
   ============================== */
function submitForm() {
  const name = document.getElementById('name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const email = document.getElementById('email').value.trim();

  if (!name || !phone) {
    alert('Please fill in your name and phone number.');
    return;
  }

  // Show success
  document.getElementById('form-success').style.display = 'block';

  // Clear fields
  ['name','phone','email','checkin','checkout','message'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('room-type').value = '';

  // Build WhatsApp message
  const checkin = document.getElementById('checkin')?.value || 'TBD';
  const checkout = document.getElementById('checkout')?.value || 'TBD';
  const roomType = document.getElementById('room-type')?.value || 'Not specified';
  const msgText = `Hello Shri Balaji Resort!%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AEmail: ${encodeURIComponent(email)}%0ACheck-in: ${checkin}%0ACheck-out: ${checkout}%0ARoom: ${encodeURIComponent(roomType)}`;

  // Open WhatsApp after short delay
  setTimeout(() => {
    window.open(`https://wa.me/919079792240?text=${msgText}`, '_blank');
  }, 1500);

  // Hide success after 6 seconds
  setTimeout(() => {
    const s = document.getElementById('form-success');
    if (s) s.style.display = 'none';
  }, 6000);
}

/* ==============================
   9. MOUSE GLOW EFFECT
   ============================== */
let glowEl = null;

document.addEventListener('mousemove', e => {
  if (!glowEl) {
    glowEl = document.createElement('div');
    glowEl.style.cssText = `
      pointer-events: none; position: fixed; z-index: 0;
      width: 300px; height: 300px; border-radius: 50%;
      background: radial-gradient(circle, rgba(201,168,76,0.05) 0%, transparent 70%);
      transform: translate(-50%, -50%);
      transition: left 0.12s ease, top 0.12s ease;
    `;
    document.body.appendChild(glowEl);
  }
  glowEl.style.left = e.clientX + 'px';
  glowEl.style.top = e.clientY + 'px';
});

/* ==============================
   10. SMOOTH SCROLL FOR ALL ANCHOR LINKS
   ============================== */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const navH = navbar ? navbar.offsetHeight : 70;
      const top = target.getBoundingClientRect().top + window.scrollY - navH;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

/* ==============================
   11. ROOM CARDS — 3D HOVER
   ============================== */
document.querySelectorAll('.room-card').forEach(card => {
  card.addEventListener('mousemove', e => {
    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const rotX = (y - cy) / cy * -6;
    const rotY = (x - cx) / cx * 6;
    card.style.transform = `perspective(800px) rotateX(${rotX}deg) rotateY(${rotY}deg) translateY(-10px)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = '';
  });
});

/* ==============================
   12. PARALLAX ON SCROLL (subtle)
   ============================== */
window.addEventListener('scroll', () => {
  const scrollY = window.scrollY;
  const heroBg = document.querySelector('.hero-bg');
  if (heroBg) {
    heroBg.style.transform = `translateY(${scrollY * 0.35}px)`;
  }
});

/* ==============================
   13. SERVICE CARDS — HOVER GLOW TRAIL
   ============================== */
document.querySelectorAll('.service-card').forEach(card => {
  card.addEventListener('mousemove', e => {
    const rect = card.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    card.style.setProperty('--mouse-x', `${x}%`);
    card.style.setProperty('--mouse-y', `${y}%`);
  });
});

/* ==============================
   14. NUMBER COUNTER ANIMATION
   ============================== */
function animateCount(el, target, duration = 1800) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if (start >= target) { start = target; clearInterval(timer); }
    el.textContent = Math.floor(start) + (el.dataset.suffix || '');
  }, 16);
}

// Trigger on scroll into view
const statNums = document.querySelectorAll('.stat-num');
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const raw = el.textContent.replace(/[^0-9]/g, '');
      const suffix = el.textContent.replace(/[0-9]/g, '');
      el.dataset.suffix = suffix;
      animateCount(el, parseInt(raw));
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });

statNums.forEach(num => counterObserver.observe(num));

/* ==============================
   15. SECTION NEON DIVIDER LINES (CSS injection)
   ============================== */
// Adds animated gold line dividers between sections dynamically
document.querySelectorAll('.section-header').forEach(header => {
  const divider = document.createElement('div');
  divider.style.cssText = `
    width: 60px; height: 3px; margin: 16px auto 0;
    background: linear-gradient(90deg, transparent, #c9a84c, transparent);
    border-radius: 2px;
    animation: expandLine 2s ease-out forwards;
  `;
  header.appendChild(divider);
});

// Inject the keyframes
const styleEl = document.createElement('style');
styleEl.textContent = `
  @keyframes expandLine {
    from { width: 0px; opacity: 0; }
    to { width: 60px; opacity: 1; }
  }
`;
document.head.appendChild(styleEl);

console.log('✦ Shri Balaji Resort — Loaded Successfully ✦');
